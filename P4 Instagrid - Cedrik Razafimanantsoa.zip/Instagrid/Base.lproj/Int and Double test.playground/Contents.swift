import UIKit

let numéro: Int = 9000000001
print(numéro)

let weeks = 465/7
print("There are \(weeks) weeks until the event.")

let realWeeks: Double = 465/7
print("There are \(realWeeks) weeks until the event.")

let days = 465%7
print("There are \(weeks) weeks and \(days) until the event.")

let number = 465
let isMultipe = number.isMultiple(of: 7)
print(isMultipe)
